package io.broker.api.client.domain.general;

/**
 * Rate limiters.
 */
public enum RateLimitType {
    REQUEST_WEIGHT,
    ORDERS
}
