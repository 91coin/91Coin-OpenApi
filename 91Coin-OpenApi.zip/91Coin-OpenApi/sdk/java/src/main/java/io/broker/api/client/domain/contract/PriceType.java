package io.broker.api.client.domain.contract;

public enum PriceType {
    INPUT,
    OPPONENT,
    QUEUE,
    OVER,
    MARKET
}
