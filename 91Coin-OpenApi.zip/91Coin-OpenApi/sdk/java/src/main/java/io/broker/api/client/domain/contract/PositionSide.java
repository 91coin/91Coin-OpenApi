package io.broker.api.client.domain.contract;

public enum PositionSide {
    LONG,
    SHORT
}
