package io.broker.api.client.domain.contract;

public enum OrderType {
    LIMIT,
    STOP
}
