package io.broker.api.client.domain.contract;

public enum OrderSide {
    BUY_OPEN,
    SELL_OPEN,
    BUY_CLOSE,
    SELL_CLOSE
}
