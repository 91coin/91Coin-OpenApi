package io.broker.api.client.domain.contract;

public enum TimeInForce {
    GTC,
    FOK,
    IOC,
    LIMIT_MAKER
}
