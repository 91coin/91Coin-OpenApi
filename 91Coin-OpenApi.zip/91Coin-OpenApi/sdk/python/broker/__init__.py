import logging

version = "2.1.1"

user_agent = "Broker-P V" + version

broker_log = logging.getLogger("broker-client")
