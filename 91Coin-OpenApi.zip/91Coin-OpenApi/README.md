# bhex openapi

* doc directory: include the openapi doc, you could make your sdk with the doc.
* SDK directory: include java and python sdk

If you have any questions, please post your issues on the board, We will ack you as soon as we can.Thanks.

friendly api doc at : <https://apidocs.91coin.pro>
